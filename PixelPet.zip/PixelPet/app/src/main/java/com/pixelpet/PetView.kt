package com.pixelpet

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

enum class Action { WALK, SIT, SLEEP }

// Slime originale in pixel art: 12 colonne x 8 righe, '#' = corpo.
private val SLIME = arrayOf(
    "...######...",
    "..########..",
    ".##########.",
    "############",
    "############",
    "############",
    "############",
    "############",
)

private val BODY_COLOR = 0xFF7BD389.toInt()
private val OUTLINE = 0xFF2E6B3F.toInt()
private val INK = 0xFF1F2A24.toInt()
private val CHEEK = 0xFFFF8FA3.toInt()
private val SWEAT = 0xFF6EC6FF.toInt()

/** Disegna il pet. Il servizio decide dove sta e cosa fa, qui si mostra solo. */
class PetView(context: Context) : View(context) {

    var action = Action.WALK
    private var eatingUntil = 0L
    private var heartUntil = 0L
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    fun eat() {
        eatingUntil = now() + 1500
    }

    fun heart() {
        heartUntil = now() + 1800
    }

    private fun now() = SystemClock.uptimeMillis()

    private fun cell(canvas: Canvas, x: Float, y: Float, c: Float, color: Int, alpha: Int = 255) {
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.alpha = alpha.coerceIn(0, 255)
        canvas.drawRect(x, y, x + c, y + c, paint)
    }

    private fun emoji(canvas: Canvas, text: String, x: Float, y: Float, size: Float) {
        textPaint.textSize = size
        canvas.drawText(text, x, y, textPaint)
    }

    override fun onDraw(canvas: Canvas) {
        val t = now() / 1000f
        val w = width.toFloat()
        val h = height.toFloat()
        val c = min(w / 14f, h / 11f)
        val ox = (w - 12f * c) / 2f
        val sleeping = action == Action.SLEEP
        val walking = action == Action.WALK

        // saltellino mentre cammina, respiro leggero mentre dorme
        val bob = when {
            walking -> abs(sin(t * 9f)) * 0.6f * c
            sleeping -> sin(t * 1.5f) * 0.15f * c
            else -> 0f
        }
        val oy = h - 9f * c - bob

        // ombra a terra
        paint.style = Paint.Style.FILL
        paint.color = 0xFF000000.toInt()
        paint.alpha = 70
        canvas.drawOval(RectF(ox + 0.5f * c, h - 1.1f * c, ox + 11.5f * c, h - 0.3f * c), paint)

        // corpo con ombra pixel
        for (r in SLIME.indices) {
            for (col in SLIME[r].indices) {
                if (SLIME[r][col] == '#') cell(canvas, ox + col * c + 0.2f * c, oy + r * c + 0.2f * c, c, OUTLINE, 90)
            }
        }
        for (r in SLIME.indices) {
            for (col in SLIME[r].indices) {
                if (SLIME[r][col] == '#') cell(canvas, ox + col * c, oy + r * c, c, BODY_COLOR)
            }
        }

        fun put(col: Int, row: Int, color: Int = INK, alpha: Int = 255) =
            cell(canvas, ox + col * c, oy + row * c, c, color, alpha)

        // guance: rosse quando è felice
        val happy = heartUntil > now() || PetState.joy > 70f
        if (happy) for (col in listOf(1, 2, 9, 10)) put(col, 5, CHEEK, 170)

        // occhi: chiusi se dorme o se sbatte le palpebre
        val blinking = now() % 3600L < 150L
        if (sleeping || blinking) {
            for (col in listOf(3, 4, 7, 8)) put(col, 4)
        } else {
            for (r in 3..4) for (col in listOf(3, 4, 7, 8)) put(col, r)
        }

        // bocca: aperta mentre mangia
        if (eatingUntil > now()) {
            for (r in 5..6) for (col in listOf(5, 6)) put(col, r)
        } else {
            put(5, 5)
            put(6, 5)
        }

        // goccia di sudore se ha fame
        if (PetState.fullness < 25f) put(11, 1, SWEAT)

        // simboli sopra la testa
        val headY = oy - 0.6f * c
        val float = abs(sin(t * 3f)) * 0.5f * c
        if (sleeping) emoji(canvas, "💤", ox + 10f * c, headY - float, 2.4f * c)
        if (eatingUntil > now()) emoji(canvas, "🍎", w / 2f, headY - float, 2.4f * c)
        if (heartUntil > now()) emoji(canvas, "❤️", w / 2f, headY - float, 2.4f * c)

        postInvalidateDelayed(33)
    }
}
