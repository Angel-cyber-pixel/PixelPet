package com.pixelpet

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var stats: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PetState.init(this)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1E2B24.toInt())
            setPadding(dp(24), dp(32), dp(24), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "PixelPet 🌿"
            textSize = 26f
            setTextColor(Color.WHITE)
        })

        status = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFCFE8D6.toInt())
            setPadding(0, dp(12), 0, dp(8))
        }
        root.addView(status)

        stats = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFCFE8D6.toInt())
            setPadding(0, 0, 0, dp(16))
        }
        root.addView(stats)

        root.addView(button("1. Consenti la sovrapposizione alle altre app") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("2. Fai comparire il pet") {
            startService(Intent(this, PetService::class.java))
        })
        root.addView(button("🍎 Dai da mangiare") {
            PetState.feed()
            refresh()
        })
        root.addView(button("🎾 Gioca") {
            PetState.play()
            refresh()
        })

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        status.text = if (Settings.canDrawOverlays(this)) {
            "✅ Permesso concesso"
        } else {
            "❌ Serve il permesso di sovrapposizione"
        }
        stats.text = "Sazietà ${bar(PetState.fullness)}\nFelicità ${bar(PetState.joy)}"
    }

    private fun bar(value: Float): String {
        val n = (value / 10f).toInt().coerceIn(0, 10)
        return "█".repeat(n) + "░".repeat(10 - n) + " ${value.toInt()}%"
    }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }
}
