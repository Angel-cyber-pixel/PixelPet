package com.pixelpet

import android.content.Context
import android.content.SharedPreferences

/** Statistiche del pet, salvate tra un'apertura e l'altra. Scendono col tempo. */
object PetState {
    private const val PREFS = "pet"

    @Volatile var fullness = 80f   // sazietà 0..100
    @Volatile var joy = 80f        // felicità 0..100

    private var prefs: SharedPreferences? = null
    private var lastTick = System.currentTimeMillis()
    private var lastSave = 0L

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p
        val now = System.currentTimeMillis()
        // applica il calo avvenuto mentre l'app era chiusa
        val minutes = ((now - p.getLong("last", now)) / 60000f).coerceAtLeast(0f)
        fullness = (p.getFloat("fullness", 80f) - minutes * FULL_DECAY).coerceIn(0f, 100f)
        joy = (p.getFloat("joy", 80f) - minutes * JOY_DECAY).coerceIn(0f, 100f)
        lastTick = now
    }

    /** Chiamata a ogni frame dal servizio: fa scendere lentamente i valori. */
    fun tick() {
        val now = System.currentTimeMillis()
        val minutes = (now - lastTick) / 60000f
        lastTick = now
        fullness = (fullness - minutes * FULL_DECAY).coerceIn(0f, 100f)
        joy = (joy - minutes * JOY_DECAY).coerceIn(0f, 100f)
        if (now - lastSave > 30_000L) save()
    }

    fun feed() {
        fullness = (fullness + 35f).coerceAtMost(100f)
        joy = (joy + 5f).coerceAtMost(100f)
        save()
    }

    fun play() {
        joy = (joy + 30f).coerceAtMost(100f)
        fullness = (fullness - 5f).coerceAtLeast(0f)
        save()
    }

    fun pet() {
        joy = (joy + 8f).coerceAtMost(100f)
        save()
    }

    private fun save() {
        lastSave = System.currentTimeMillis()
        prefs?.edit()
            ?.putFloat("fullness", fullness)
            ?.putFloat("joy", joy)
            ?.putLong("last", lastSave)
            ?.apply()
    }

    private const val FULL_DECAY = 0.4f  // punti persi al minuto
    private const val JOY_DECAY = 0.2f
}
