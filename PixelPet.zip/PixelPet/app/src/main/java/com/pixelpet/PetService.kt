package com.pixelpet

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import kotlin.math.abs
import kotlin.random.Random

/** Tiene il pet in vita sopra le altre app e lo fa camminare, sedere e dormire. */
class PetService : Service() {

    companion object {
        private const val PET_W_DP = 96
        private const val PET_H_DP = 80
        private const val BOTTOM_DP = 48   // sopra la barra di navigazione
    }

    private val handler = Handler(Looper.getMainLooper())
    private var attached = false
    private lateinit var wm: WindowManager
    private lateinit var view: PetView
    private lateinit var params: WindowManager.LayoutParams

    private var density = 1f
    private var screenW = 0
    private var petW = 0

    private var x = 0
    private var targetX = 0
    private var action = Action.WALK
    private var pauseUntil = 0L

    private val loop = object : Runnable {
        override fun run() {
            step()
            handler.postDelayed(this, 33L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!attached) startPet()
        return START_STICKY
    }

    private fun startPet() {
        PetState.init(this)
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        density = resources.displayMetrics.density
        screenW = resources.displayMetrics.widthPixels
        petW = (PET_W_DP * density).toInt()
        val petH = (PET_H_DP * density).toInt()

        view = PetView(this).apply { setOnClickListener { onPetTapped() } }
        val startX = (screenW * 0.2f).toInt()
        x = startX
        params = WindowManager.LayoutParams(
            petW,
            petH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            this.x = startX
            y = (BOTTOM_DP * density).toInt()
        }
        try {
            wm.addView(view, params)
            attached = true
        } catch (e: Exception) {
            stopSelf()
            return
        }
        pickNextWalk()
        handler.post(loop)
    }

    private fun maxX() = (screenW - petW).coerceAtLeast(1)

    private fun pickNextWalk() {
        targetX = Random.nextInt(0, maxX())
        action = Action.WALK
        view.action = action
    }

    private fun onPetTapped() {
        PetState.pet()
        view.heart()
    }

    private fun arrive() {
        val now = SystemClock.uptimeMillis()
        val roll = Random.nextFloat()
        when {
            roll < 0.15f -> {
                action = Action.SLEEP
                pauseUntil = now + Random.nextLong(8000L, 15000L)
            }
            roll < 0.6f -> {
                action = Action.SIT
                pauseUntil = now + Random.nextLong(2000L, 5000L)
            }
            else -> {
                pickNextWalk()
                return
            }
        }
        view.action = action
    }

    private fun step() {
        PetState.tick()
        val speed = 1.6f * density
        when (action) {
            Action.WALK -> {
                val diff = targetX - x
                if (abs(diff) <= speed) {
                    x = targetX
                    arrive()
                } else {
                    x += if (diff > 0) speed.toInt().coerceAtLeast(1) else -speed.toInt().coerceAtLeast(1)
                }
            }
            Action.SIT, Action.SLEEP -> {
                if (SystemClock.uptimeMillis() >= pauseUntil) pickNextWalk()
            }
        }
        x = x.coerceIn(0, maxX())
        if (attached) {
            params.x = x
            try {
                wm.updateViewLayout(view, params)
            } catch (e: Exception) {
                // la finestra è stata chiusa dal sistema: il servizio si ferma
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        if (attached) {
            try {
                wm.removeView(view)
            } catch (e: Exception) {
            }
            attached = false
        }
        super.onDestroy()
    }
}
